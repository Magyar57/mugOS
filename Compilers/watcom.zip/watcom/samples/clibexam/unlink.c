#include <io.h>

void main()
  {
    unlink( "vm.tmp" );
  }
