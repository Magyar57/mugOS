
#include <sys/types.h>
#include <direct.h>

void main()
  {
    mkdir( "c:\\watcom" );
  }

