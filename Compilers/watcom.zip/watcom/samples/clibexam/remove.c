#include <stdio.h>

void main()
  {
    remove( "vm.tmp" );
  }
