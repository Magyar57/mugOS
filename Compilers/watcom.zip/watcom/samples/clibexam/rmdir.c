
#include <sys/types.h>
#include <direct.h>

void main()
  {
    rmdir( "c:\\watcom" );
  }

