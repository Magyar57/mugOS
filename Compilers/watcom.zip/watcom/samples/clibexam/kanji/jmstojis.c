#include <stdio.h>
#include <jstring.h>

void main()
  {
    unsigned short c;

    c = jmstojis( 0x8171 );
    printf( "%x\n", c );
  }
