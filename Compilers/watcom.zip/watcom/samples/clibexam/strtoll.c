#include <stdlib.h>

void main()
{
    long long int v;

    v = strtoll( "12345678909876", NULL, 10 );
}
